<div class="form-group mb-3">
    <p><?php echo e(trans('plugins/contact::contact.shortcode_content_description')); ?></p>
</div>
<?php /**PATH /Users/q/workspace/martfury/platform/plugins/contact/resources/views/partials/short-code-admin-config.blade.php ENDPATH**/ ?>